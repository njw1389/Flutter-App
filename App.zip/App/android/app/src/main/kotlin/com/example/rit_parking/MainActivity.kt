package com.example.rit_parking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
